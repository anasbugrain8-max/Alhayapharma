ضع هنا خط عربي بصيغة TTF باسم:
NotoNaskhArabic-Regular.ttf

يمكنك تحميله مجاناً من Google Fonts:
https://fonts.google.com/noto/specimen/Noto+Naskh+Arabic

بدون هذا الملف، سيعمل البوت بشكل طبيعي لكن ملفات PDF لن تعرض النص العربي بشكل صحيح.
